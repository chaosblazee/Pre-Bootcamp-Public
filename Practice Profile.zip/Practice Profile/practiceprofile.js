function moreLikes(el) {
    el.nextElementSibling.innerText++
}

function search(event) {
    event.preventDefault()
    alert(`You're searching for ${document.getElementById('information').value}`)
}